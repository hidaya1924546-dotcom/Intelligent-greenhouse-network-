#include <Arduino.h>
#include <WiFi.h>
#include <Firebase_ESP_Client.h>
#include <DHT.h>
#include <time.h>
#include "addons/TokenHelper.h"

#define WIFI_SSID       "greenhouse"
#define WIFI_PASSWORD   "12345678"

#define API_KEY         "AIzaSyARDleBLlRVexJ33oxY6ehPJXJo7llOeMk"
#define DATABASE_URL    "https://intelligent-greenhouse-network-default-rtdb.firebaseio.com/"

#define DHTPIN      14
#define DHTTYPE     DHT22
#define WATER_PIN   34
#define FAN_PIN     33
#define LAMP_PIN    32
#define PUMP_PIN    25

#define RELAY_ON    LOW
#define RELAY_OFF   HIGH
#define WATER_IS_DRY  500 

DHT dht(DHTPIN, DHTTYPE);
FirebaseData fbdo;
FirebaseData streamData;
FirebaseAuth auth;
FirebaseConfig config;

float t_max = 30, t_min = 15, h_max = 80, h_min = 40;
String current_plant = "";
unsigned long lastSensor = 0;

void fetchPlantSettings(const String& plant) {
  String path = "/Plant-settings/" + plant;
  if (Firebase.RTDB.getJSON(&fbdo, path)) {
    FirebaseJson &json = fbdo.jsonObject();
    FirebaseJsonData result;

    if (json.get(result, "Temp_max") || json.get(result, "Tem_max")) t_max = result.to<float>();
    if (json.get(result, "Temp_min") || json.get(result, "Tem_min")) t_min = result.to<float>();
    if (json.get(result, "Hum_max") || json.get(result, "Hum"))     h_max = result.to<float>();
    if (json.get(result, "Hum_min"))                                h_min = result.to<float>();
    
    Serial.println("Updated thresholds for: " + plant);
  }
}

void streamCallback(FirebaseStream data) {
  if (data.dataType() == "string") {
    String newPlant = data.stringData();
    if (newPlant.length() > 0 && newPlant != current_plant) {
      current_plant = newPlant;
      fetchPlantSettings(current_plant);
    }
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(FAN_PIN, OUTPUT);
  pinMode(LAMP_PIN, OUTPUT);
  pinMode(PUMP_PIN, OUTPUT);

  digitalWrite(FAN_PIN, RELAY_OFF);
  digitalWrite(LAMP_PIN, RELAY_OFF);
  digitalWrite(PUMP_PIN, RELAY_OFF);

  dht.begin();

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi Connected");

  configTime(0, 0, "pool.ntp.org", "time.nist.gov");

  config.api_key = API_KEY;
  config.database_url = DATABASE_URL;
  config.token_status_callback = tokenStatusCallback;

  if (Firebase.signUp(&config, &auth, "", "")) {
    Serial.println("Firebase Auth OK");
  }

  Firebase.begin(&config, &auth);
  Firebase.reconnectWiFi(true);

  Firebase.RTDB.beginStream(&streamData, "/Selected_Plant");
  Firebase.RTDB.setStreamCallback(&streamData, streamCallback, [](bool timeout){});
}

void loop() {
  if (Firebase.ready() && (millis() - lastSensor > 2000)) {
    lastSensor = millis();

    float h = dht.readHumidity();
    float t = dht.readTemperature();
    int water = analogRead(WATER_PIN);

    if (isnan(h) || isnan(t)) {
      Serial.println("DHT Sensor error");
      return;
    }

    bool lampOn = (t < t_min);
    bool fanOn = ((t > t_max) || (h > h_max)) && !lampOn;
    bool pumpOn = (water < WATER_IS_DRY);

    digitalWrite(FAN_PIN, fanOn ? RELAY_ON : RELAY_OFF);
    digitalWrite(LAMP_PIN, lampOn ? RELAY_ON : RELAY_OFF);
    digitalWrite(PUMP_PIN, pumpOn ? RELAY_OFF : RELAY_ON);

    FirebaseJson json;
    json.set("Temperature", (float)((int)(t * 10)) / 10.0);
    json.set("Humidity", (float)((int)(h * 10)) / 10.0);
    json.set("WaterLevel", water);
    json.set("FanStatus", fanOn ? "ON" : "OFF");
    json.set("LampStatus", lampOn ? "ON" : "OFF");
    json.set("PumpStatus", pumpOn ? "ON" : "OFF");
    json.set("Heartbeat", (int)(millis() / 1000));

    if (Firebase.RTDB.updateNode(&fbdo, "/Monitor", &json)) {
      Serial.printf("T:%.1f H:%.1f W:%d | L:%s F:%s P:%s\n", 
                    t, h, water, 
                    lampOn?"ON":"OFF", fanOn?"ON":"OFF", pumpOn?"ON":"OFF");
    }
  }
}